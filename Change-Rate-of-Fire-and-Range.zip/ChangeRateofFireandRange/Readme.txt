The rate is set to be about the same as CSGO when the skill level of the various guns is raised.
Since this mod is intended to be played on "Insane", other difficulty levels may make it too easy.
To change the rate, change the value in {~~[@name='RoundsPerMinute'][@operation='base_set']/@value">xxx</set>} to the desired value.
To change the number of magazines, change the value in [~[@name='MagazineSize'][@operation='base_set']/@value">13</set>] to the desired value.
